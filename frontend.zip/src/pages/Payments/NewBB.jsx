import React from 'react'
import PaymentForm from '../../components/PAyment/Payment'

const NewBB = () => {
    return (
        <PaymentForm />
    )
}

export default NewBB